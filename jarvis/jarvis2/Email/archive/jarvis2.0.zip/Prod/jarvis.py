#----------------------------------------------------------------------
#||  Project Jarvis
#||  Version 1.1
#||
#||  Author:         Ryan Wright
#||  Email:          rdwright5127@gmail.com
#||  Last Modified:  26.6.13
#||
#||  Versions:
#||     1.1 - 26.6.13
#||         Classes created for User and UserList. Update implements those
#||         classes.More executable commands introduced. Admin rights made.
#||     1.0 - 12.6.13
#||        Individual pieces come together to make a functioning product.
#||        Transferred to RasPi.
#||     0.3 - 11.6.13
#||        Mode Array Introduced. Prompt Conditioning Works.
#||     0.2 - 10.6.13
#||        Parroting functions work.
#||     0.1 - 9.6.13
#||         Email Functions work
#||
#||  File Description: jarvis.py
#||     This file is the main program where the rest of the program
#||     branches off from. A loop continually checks for new mail and
#||     Then executes the incoming prompt
#|| 

from classes import *
from execute import *

tempModeArray = getModeArrayDefaults()

try:
    print('Hello sir.\n')
    while True:
        time.sleep(5)
        newPrompt = getprompt()

        #if there's a message send it through the works
        if newPrompt != NO_MESSAGE:

            #Just say something so we know we got something
            print("----------------------------------------\n\tNew Message Recieved!\n----------------------------------------\n")

            #parrot
            parrot(newPrompt, tempModeArray)

            #Do security checks
            #if it fails promptTuple will be a string with the error message
            returns, promptTuple, myUser = conditionPrompt(newPrompt,tempModeArray)

            #if it is sucessful
            if returns == SUCCESS:
                #execute(promptTuple() = (command, parameter array), user, modeArray )
                result = execute(promptTuple,myUser,tempModeArray)
                print(result)
                                      
            else: #FAILURE
                print(promptTuple)
                if tempModeArray[3] == False:
                    sendmsg(myUser.add,promptTuple,tempModeArray[0])

            print("\n----------------------------------------\n\n")
                                
except KeyboardInterrupt:
    print('Goodbye Sir!')
    time.sleep(2)
