#----------------------------------------------------------------------
#||  Project Jarvis
#||  Version 1.1
#||
#||  Author:         Ryan Wright
#||  Email:          rdwright5127@gmail.com
#||  Last Modified:  26.6.13
#||
#||  Versions:
#||     1.1 - 26.6.13
#||         Classes created for User and UserList. Update implements those
#||         classes. More executable commands introduced. Admin rights made.
#||     1.0 - 12.6.13
#||        Individual pieces come together to make a limited functioning product.
#||        Transferred to RasPi.
#||     0.3 - 11.6.13
#||        Mode Array Introduced. Prompt Conditioning Works.
#||     0.2 - 10.6.13
#||        Parroting functions work.
#||     0.1 - 9.6.13
#||         Email Functions work
#||
#||  File Description: execute.py
#||     This file executes the prompt after it has been processed
#|| 

from classes import *

def execute(promptTuple, myUser, modeArray):
    #Split promptTuple up
    cmd, paramList = promptTuple
    cmd = cmd.upper()
    adminList = userList("admin.jvs")
    myList = userList("users.jvs")

    try:
        #Admin Powers
        if adminList.getUserbyName(myUser.name) != FAILURE:
            #Text everyone!
            #paramList = <msg>
            if cmd == "TEXTALL":
                myList.textAll(paramList[0])
                return(SUCCESS)

            #In this case we can change another's password
            #paramList = <otherUser> <newPwd>
            elif cmd == "CHANGEPASS":
                otherUser = myList.getUserbyName(paramList[0])
                if otherUser != FAILURE:
                    myList.changePass(otherUser, paramList[1])
                    return(SUCCESS)
                #else: I'm changing my own password and it'll go down south
                #unless my password is someone else's name then i'm in trouble
                    

            #Add a user
            #paramList = <otherName> <otherAdd> <otherPwd>
            elif cmd == "ADDUSER":
                myList.addUser(paramList[0],paramList[1],paramList[2])
                return(SUCCESS)

            #Delete a user
            #paramList = <otherName>
            elif cmd == "DELUSER":
                otherUser = myList.getUserbyName(paramList[0])
                if otherUser == FAILURE:
                    return(FAILURE)
                else:
                    myList.delUser(otherUser)
                    return(SUCCESS)

            #Backup the userList
            #paramList = <>
            elif cmd == "BACKUP":
                myList.backup()
                return(SUCCESS)

            #Recover the backup of the userList
            #paramList = <>
            elif cmd == "RECOVER":
                myList.recover()
                return(SUCCESS)
                
            #else: not an admin power and if it is not valid it'll get caught later
            

        #The rest of the mortals

        #Change your password
        #ParamList = <newPwd>
        if cmd == "CHANGEPASS":
            myUser.changePwd(paramList[0])
            return(SUCCESS)

        elif cmd == "LIGHTSON":
            print("Lights ON...")
            #lightsOn()
            return(SUCCESS)
        
        elif cmd == "LIGHTSOFF":
            print("Lights OFF...")
            #lightsOff()
            return(SUCCESS)
            
        else:
            return([FAILURE,"Command does not exist"])
        
    except IndexError:
        return([FAILURE, "Prompt lacking parameters"])

#Testing
#tempUser = User("Ryan","4846808235@txt.att.net","X")
#result = execute(["ligHTsoFF", []],tempUser, [5,False,False,False])
#print(result)
