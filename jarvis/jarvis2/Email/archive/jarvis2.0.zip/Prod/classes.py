#----------------------------------------------------------------------
#||  Project Jarvis
#||  Version 1.1
#||
#||  Author:         Ryan Wright
#||  Email:          rdwright5127@gmail.com
#||  Last Modified:  26.6.13
#||
#||  Versions:
#||     1.1 - 26.6.13
#||         Classes created for User and UserList. Update implements those
#||         classes.More executable commands introduced. Admin rights made.
#||     1.0 - 12.6.13
#||        Individual pieces come together to make a functioning product.
#||        Transferred to RasPi.
#||     0.3 - 11.6.13
#||        Mode Array Introduced. Prompt Conditioning Works.
#||     0.2 - 10.6.13
#||        Parroting functions work.
#||     0.1 - 9.6.13
#||         Email Functions work
#||
#||  File Description: functions.py
#||      This file contains most of the functions that will be used
#||      in the program. They are organized by type:
#||          -Mail Functions
#||          -User/userList Classes
#||          -Mode Functions
#||          -Input Cleanup Function
#||      Further descriptions are in the subsets below
#||      


import imaplib
import email
import os
import smtplib
import time
import sqlite3

#Just some various Constants
ADMIN = ["Admin","4846808235@txt.att.net","four"]
NO_MESSAGE = 'No new messages'
SUCCESS, FAILURE, CRAP = 1, -1, 0
ON, OFF, NULL = 1, -1, 0

#                   --Mail Functions--
#   Functions involving the IMAP and SMTP processes of recieving
#   and sending emails. Don't mess with these unless you really have
#   to cause they were a pain to get to work. Functions include:
#       -getprompt()
#       -sendmsg(varTo, varMsg, varUser = 'jarvis104Mckee@gmail.com', varPass = 'jarvis104',verbose)
#

#Goes to the gmail account and gets the most recent unread email
#IN: Nothing
#OUT: msgTuple = [AddressOfSender, Message]
def getprompt():
    USER = 'jarvis104Mckee@gmail.com'
    PASSWORD = 'jarvis104'

    mail = imaplib.IMAP4_SSL('imap.gmail.com')
    mail.login(USER,PASSWORD)

    mail.select('Inbox')

    resp, data = mail.search(None, 'UnSeen')

    nullMsg = data[0].decode('utf-8')
    if nullMsg == '':
        return('No new messages')
    
    for num in (data[0].split()):
      resp, msg = mail.fetch(num, '(RFC822)')

      for response_part in msg:
          if isinstance(response_part, tuple):
              message = email.message_from_bytes(response_part[1])
              varFrom = message['from']

              for part in message.walk():
                  if part.get_content_type() == 'text/plain':
                      varBody = part.get_payload(decode=True)

                      #remove the brackets around the sender email address
                      head = varFrom.find('<')
                      varFrom = varFrom[head+1:]
                      varFrom = varFrom.replace('>', '')

                      #decode the body and make it pretty
                      varBody = varBody.decode('utf-8')
                        #for ATT
                      varBody = varBody.replace("\r\n--\r\n==================================================================\r\nThis mobile text message is brought to you by AT&T\r\n",'')

                        #for VTEXT
                      varBody = varBody.replace("\r\n",'')

                  elif part.get_content_type() == 'text/html':
                      varBody = part.get_payload(decode=True)
                      varBody = varBody.decode('utf-8')
                      head = varBody.find('<td>')
                      tail = varBody.rfind('</td>')
                      varBody = varBody[head+4:tail]
                      varBody = varBody.replace("\r\n","")
                      varBody = varBody.strip()
                      
                  else:
                      continue
    msgTuple = [varFrom, varBody] 
    mail.close()
    mail.logout()
    return(msgTuple)

#Sends a message
#IN: varTo = Address to send from, varMsg = Message to send
#OUT: Success or failure
def sendmsg(varTo, varMsg, verbose, varUser = 'jarvis104Mckee@gmail.com', varPass = 'jarvis104'):
    #Set variables
    to = varTo
    gmail_user = varUser
    gmail_pwd = varPass

    #Login
    smtpserver = smtplib.SMTP("smtp.gmail.com",587)
    smtpserver.ehlo()
    smtpserver.starttls()
    smtpserver.ehlo
    smtpserver.login(gmail_user, gmail_pwd)
    
    
    msg = "\r\n".join(["From: Jarvis","To: " + varTo,"A message From Jarvis","",varMsg,""])
    printmsg = "\r\n--->".join(["--->From: Jarvis","To: " + varTo,"A message From Jarvis","",varMsg,""])

    try:
        smtpserver.sendmail(gmail_user, to, msg.encode('utf-8'))
        if verbose > 0:
            print("-->Message sent:\n")
        if verbose > 1:
            print(printmsg)
    except SMTPException:
        print("SMTP Error")
    smtpserver.close()
    return

#                       --UserList Functions--
#   UserList Functions deal with the userList which exists in a file outside
#   of the program and needs to come inside. The userList is comprised of
#   Users.
#

class User:
    name = ""
    add = ""
    pwd = ""
    
    def __init__(self):
        self.name = "name"
        self.add = "add"
        self.pwd = "pwd"

    def __init__(self, name, add, pwd):
        self.name = name
        self.add = add
        self.pwd = pwd

    def changePwd(self,newPwd):
        self.pwd = newPwd

class userList:
    source = "source.jvs"
    userList = []
    
    def __init__(self, source):
        self.source = source
        self.userList = self.getList()

    def getList(self):
        tempList = []
        f = open(self.source)
        for i in f.readlines():
            userData = i.replace("\n","")
            li = tuple(filter(None, userData.split(';')))
            newUser = User(li[0],li[1],li[2])
            tempList.append(newUser)
        f.close()
        return(tempList)

    def getUserbyAdd(self, userAdd):
        returnUser = None
        for user in self.userList:
            if user.add == userAdd:
                returnUser = user
        if returnUser == None:
            return(FAILURE)
        else: #was found
            return(returnUser)

    def getUserbyName(self, userName):
        returnUser = None
        for user in self.userList:
            if user.name == userName:
                returnUser = user
        if returnUser == None:
            return(FAILURE)
        else: #was found
            return(returnUser)

    def textAll(self, msg):
        for user in self.userList:
            sendmsg(user.add,msg)
        return

    def changePass(self, myUser, newPwd):
        myUser.changePwd(newPwd)
        return

    def exportUserList(self,newSource):
        file = open(newSource, "w")
        for user in self.userList:
            file.write(user.name+";"+user.add+";"+user.pwd+"\n")
        return

    def backup(self):
        self.exportUserList("backup.jvs")
        return

    def recover(self):
        tempUserList = userList("backup.jvs")
        tempUserList.exportUserList("users.jvs")
        self.userList = self.getList()
        return

    def addUser(self, userName, userAdd, userPwd):
        newUser = User(userName, userAdd, userPwd)
        self.userList.append(newUser)
        self.exportUserList(self.source)
        return

    def delUser(self, myUser):
        self.userList.remove(myUser)
        self.exportUserList(self.source)
        return

    def printUserList(self):
        print("User\t\tAddress\t\t\tPassword\n")
        for user in self.userList:
            print(user.name + "\t\t" + user.add + "\t\t\t" + user.pwd + "\n")
        return


#                           --Mode Functions--
#   Mode Functions describe and execute the different types of modes that
#   the program is capable of. See modeArray.txt in the archive folder for
#   a full list as well as a descriptionof the modeArray itself. These should
#   be the only functions that take in the modeArray because they are editing it.
#   The mode array is just a list of numbers/boolean values (tuple in future?)
#   All others in other categories should pass by value. Functions include:
#       -verboseCount(userMsg, modeArray)
#       -toggleParrotMode(userMsg,modeArray)
#       -toggleRageParrotMode(userMsg, modeArray)
#       -getModeArrayDefaults()
#   Note: When these functions are finished the message will no longer have those
#   words/values in them. Ex. "password i like -v pie -v" >>> "password i like pie"
#

#Counts the number of verbose flags in the message
#IN: takes in the message and the modeArray

def verboseCount(userMsg, modeArray):
    modeArray[0] = userMsg.count("-v") + modeArray[0]
    if modeArray[0] > 0:
        print("Verbose mode activated:\nVerbose Level " + str(modeArray[0]) +"\n")
    return(userMsg.replace('-v',''))

#toggles the ParrotMode
#IN:  takes in the message and the modeArray
#OUT: returns the message string
def toggleParrotMode(userMsg,modeArray):
    message = userMsg.split()
    for msg in message:
        if msg == "parrotMode":
            modeArray[1] = not modeArray[1]
            if not modeArray[1]:
                print("Parrot Mode Deactivated\n")
            else: #parrotMode == False
                print("Parrot Mode Activated\n")
    return(userMsg.replace('parrotMode', ''))

#toggles the RageParrotMode
#IN:  takes in the message and the modeArray
#OUT: returns the message string
def toggleRageParrotMode(userMsg,modeArray):
    message = userMsg.split()
    for msg in message:
        if msg == "rageParrotMode":
            modeArray[2] = not modeArray[2]
            if not modeArray[2]:
                print("Parrot Mode Deactivated\n")
            else: #parrotMode == False
                print("PARROT MODE ACTIVATED!!!\n")
    return(userMsg.replace('rageParrotMode', ''))

def parrot(prompt, modeArray):
    #parrotMode
    if modeArray[1] == True:
        sendmsg(prompt[0],prompt[1]+' SQUAWK',modeArray[0])
    #rageParrotMode
    if modeArray[2] == True:
        sendmsg(prompt[0],"rageParrotMode is active but I'm not going to activate it yet. You're welcome.",modeArray[0])
#        while i != 50:
#            i = i + 1
#            sendmsg(prompt[0],prompt[1]+' SQUAWK')
    return

#Sets up the default values for the modeArray
#IN: None
#OUT: modeArray
def getModeArrayDefaults():
    verbose = 2
    parrotMode = False
    rageParrotMode = False
    quiet = True
    modeArray = [verbose,parrotMode,rageParrotMode,quiet]
    return(modeArray)
    
#        --Input Cleanup Function--
#executes the prompt described in newPrompt
#IN:  newPrompt variable, verbose flag
#OUT: Success flag if successful
def conditionPrompt(newPrompt, modeArray):
    errormsg = "Somethin' strange happened!"
    myList = userList("users.jvs")

    #cleanup the prompt
    #Toggle ParrotMode
    newPrompt[1] = toggleParrotMode(newPrompt[1], modeArray)

    #Toggle RageParrotMode
    newPrompt[1] = toggleRageParrotMode(newPrompt[1], modeArray)

    #verbose flag
    newPrompt[1] = verboseCount(newPrompt[1],modeArray)

    #quiet flag
    
    if modeArray[0] > 0:
        print("-->Extracting Variables...\n")

    #Extract variables from prompt
    varPrompt = newPrompt[1]
    varUser = myList.getUserbyAdd(newPrompt[0])
            
    #Check if user is on the userList
    if varUser == FAILURE:
        tempUser = User("MysteryMan",newPrompt[0],"VOID")
        errormsg = "You are not a user. You have been rejected."
        return([FAILURE,errormsg,tempUser])
    
    if modeArray[0] > 0:
        print("-->User " + varUser.name + " has sent a prompt.\n")
    if modeArray[0] > 1:
        print("--->Prompt sent: " + varPrompt + "\n")

    #Split up the prompt into separate words(units)
    units = varPrompt.split()
    
    #units will typically work as follows:
    # <password> <command> <additional parameters>

    promptPass = None
    command = None
    paramList = []
    
    if len(units) >= 3:
        for unit in units[2:]:
            paramList.append(unit)
        command = units[1]
    elif len(units) >= 2:
        paramList.append("Empty")
        command = units[1]
    elif len(units) >= 1:
        promptPass = units[0]
    else:
        errormsg = "Empty prompt"
        return([FAILURE,errormsg,varUser])
    
    if units[0] != varUser.pwd: #password is not the same
        errormsg = "Wrong Password. Try again."
        return([FAILURE,errormsg,varUser])

    #create responding tuple
    #   function status, promptTuple = [command, parameter array]
    resultTuple = [SUCCESS, [command,paramList], varUser]
    
    return resultTuple
